This directory contains a repository that tracks a local remote.
