List the remotes that are already configured:

git remote -v 

In the path /working-remotes/...git there is a remote. Add it
with 

git add /working-remote/...git 

and check again the list of the configured remotes:

git remote -v
