# Revert the latest commit

The goal of this exercise is to learn to revert the latest commit. Enter the
`repository/` directory and perform the following steps:

 1. Revert the latest commit.
 
 2. Confirm that the commit tree indeed contains the revert commit. Confirm
    that the `recipe.txt` file no longer contains the section "Other ideas
    and hints".
