## Exercises

1. Fork the followig repository https://github.com/pojeda/pull-request-course.git

2. Clone the forked repository and check the available remotes

3. Add the upstream repository with the name "upstream"

4. Using your cloned version of the forked repository, make some modification to the
README.md file and commit them locally. Then, push the changes to the remote.
Finally, make a "pull request" from your GitHub account.
